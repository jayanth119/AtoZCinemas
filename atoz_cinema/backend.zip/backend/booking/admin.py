from django.contrib import admin
from .models import Cast, Review,Movie,Top2024Movies,soom

admin.site.register(Cast)
admin.site.register(Review)
admin.site.register(Movie)
admin.site.register(Top2024Movies)
admin.site.register(soom)