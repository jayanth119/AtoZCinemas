from django.contrib import admin
from . models import Movies250 , Tvshows250 
# Register your models here.
admin.site.register(Movies250) 
admin.site.register(Tvshows250)